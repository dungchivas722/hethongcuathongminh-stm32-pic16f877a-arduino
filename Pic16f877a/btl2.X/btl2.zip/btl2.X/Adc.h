void ADC_Initialize(void);
unsigned int ADC_Read(unsigned char channel);
char Joystick(void);